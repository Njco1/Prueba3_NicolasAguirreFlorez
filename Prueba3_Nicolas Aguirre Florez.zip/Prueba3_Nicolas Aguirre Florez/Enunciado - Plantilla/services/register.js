const name = document.getElementById('name')
const email = document.getElementById('email')
const dob = document.getElementById('dob')
const password = document.getElementById('password')

users = []
function addUser(name, email, dob, password) {
    const newUser = {
        name: name,
        email: email,
        dob: dob,
        password: password,
    }
}

console.log(addUser)
users.push(addUser)

function registerUsers() {}
return users
