// const email = document.getElementById('email1')
// const password = document.getElementById('password1')
// const login = document.getElementById('login1')

// const email1 = 'admin@example.com'
// const password1 = 'admin123'

// localStorage.setItem('emailAdmin', email1)
// localStorage.setItem('passwordAdmin', password1)

// login.addEventListener('click', () => {
//     if (
//         email1.value === 'admin@example.com' &&
//         password1.value === 'admin123'
//     ) {
//         alert('Estas logeado como admin')
//     } else {
//         alert('Credenciales incorrectas')
//     }
// })

// users = [
//     {
//     "id": "1",
//     "name": "Admin",
//     "email": "admin@example.com",
//     "password": "admin123",
//     "role": "admin"
//     }
// ]

// try {(user.email == value({
//     email: email1,
//     catch:
// }))}

// const login1 = {
//     "email": "admin@example.com",
//     "password": "admin123"
// }

// const loginJson = JSON.stringify(login1);

// if (email.value && password.value === loginJson){
//     alert('Estas logeado como admin')
// }else{
//     alert('Credenciales incorrectas')
// }

function login() {
    const users = document.login.users.value
    const password = document.login.password.value
    if (users == 'admin@example.com' && password == 'admin123') {
        window.location = '/index.html'
    }
}
